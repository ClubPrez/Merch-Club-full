export type Size = "XS" | "S" | "M" | "L" | "XL" | "2XL" | "3XL" | "4XL" | "5XL";

export const SIZES: Size[] = ["XS", "S", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL"];

export type AudienceType =
  | "average"
  | "younger"
  | "hs_students"
  | "women_focused"
  | "men_focused"
  | "athletic"
  | "plus_focused"
  | "mixed_corporate";

export interface AudienceOption {
  value: AudienceType;
  label: string;
  description: string;
}

export const AUDIENCE_OPTIONS: AudienceOption[] = [
  {
    value: "average",
    label: "General / Mixed",
    description: "Standard national average distribution",
  },
  {
    value: "younger",
    label: "Younger Crowd (18–30)",
    description: "Skews smaller — college students, young professionals",
  },
  {
    value: "hs_students",
    label: "High School Students (Jr. & Sr.)",
    description: "Juniors & seniors (~16–18) — heavy concentration in XS, S, and M; very few 2XL+",
  },
  {
    value: "women_focused",
    label: "Women-Focused",
    description: "Adjusted for women's typical size distribution",
  },
  {
    value: "men_focused",
    label: "Men-Focused",
    description: "Adjusted for men's typical size distribution",
  },
  {
    value: "athletic",
    label: "Athletic / Active",
    description: "Active community, gym-goers — centers M/L/XL",
  },
  {
    value: "plus_focused",
    label: "Plus / Larger Audience",
    description: "Skews toward larger sizes XL and above",
  },
  {
    value: "mixed_corporate",
    label: "Corporate / Office",
    description: "Broad professional workforce, slightly larger",
  },
];

export type RegionType = "national" | "state";

export interface StateData {
  code: string;
  name: string;
  sizeIndex: number;
}

export const STATES: StateData[] = [
  { code: "AL", name: "Alabama", sizeIndex: 1.8 },
  { code: "AK", name: "Alaska", sizeIndex: 0.8 },
  { code: "AZ", name: "Arizona", sizeIndex: 0.2 },
  { code: "AR", name: "Arkansas", sizeIndex: 1.6 },
  { code: "CA", name: "California", sizeIndex: -0.5 },
  { code: "CO", name: "Colorado", sizeIndex: -1.4 },
  { code: "CT", name: "Connecticut", sizeIndex: -0.3 },
  { code: "DE", name: "Delaware", sizeIndex: 0.7 },
  { code: "FL", name: "Florida", sizeIndex: 0.5 },
  { code: "GA", name: "Georgia", sizeIndex: 1.0 },
  { code: "HI", name: "Hawaii", sizeIndex: -1.2 },
  { code: "ID", name: "Idaho", sizeIndex: 0.3 },
  { code: "IL", name: "Illinois", sizeIndex: 0.6 },
  { code: "IN", name: "Indiana", sizeIndex: 1.3 },
  { code: "IA", name: "Iowa", sizeIndex: 1.0 },
  { code: "KS", name: "Kansas", sizeIndex: 0.9 },
  { code: "KY", name: "Kentucky", sizeIndex: 1.7 },
  { code: "LA", name: "Louisiana", sizeIndex: 1.9 },
  { code: "ME", name: "Maine", sizeIndex: 0.6 },
  { code: "MD", name: "Maryland", sizeIndex: 0.3 },
  { code: "MA", name: "Massachusetts", sizeIndex: -0.6 },
  { code: "MI", name: "Michigan", sizeIndex: 1.1 },
  { code: "MN", name: "Minnesota", sizeIndex: 0.4 },
  { code: "MS", name: "Mississippi", sizeIndex: 2.0 },
  { code: "MO", name: "Missouri", sizeIndex: 1.2 },
  { code: "MT", name: "Montana", sizeIndex: 0.2 },
  { code: "NE", name: "Nebraska", sizeIndex: 0.8 },
  { code: "NV", name: "Nevada", sizeIndex: 0.3 },
  { code: "NH", name: "New Hampshire", sizeIndex: -0.1 },
  { code: "NJ", name: "New Jersey", sizeIndex: -0.2 },
  { code: "NM", name: "New Mexico", sizeIndex: 0.7 },
  { code: "NY", name: "New York", sizeIndex: -0.4 },
  { code: "NC", name: "North Carolina", sizeIndex: 1.1 },
  { code: "ND", name: "North Dakota", sizeIndex: 1.0 },
  { code: "OH", name: "Ohio", sizeIndex: 1.2 },
  { code: "OK", name: "Oklahoma", sizeIndex: 1.6 },
  { code: "OR", name: "Oregon", sizeIndex: -0.3 },
  { code: "PA", name: "Pennsylvania", sizeIndex: 0.8 },
  { code: "RI", name: "Rhode Island", sizeIndex: 0.4 },
  { code: "SC", name: "South Carolina", sizeIndex: 1.4 },
  { code: "SD", name: "South Dakota", sizeIndex: 0.9 },
  { code: "TN", name: "Tennessee", sizeIndex: 1.5 },
  { code: "TX", name: "Texas", sizeIndex: 1.0 },
  { code: "UT", name: "Utah", sizeIndex: -0.8 },
  { code: "VT", name: "Vermont", sizeIndex: -0.2 },
  { code: "VA", name: "Virginia", sizeIndex: 0.4 },
  { code: "WA", name: "Washington", sizeIndex: -0.4 },
  { code: "WV", name: "West Virginia", sizeIndex: 1.9 },
  { code: "WI", name: "Wisconsin", sizeIndex: 1.0 },
  { code: "WY", name: "Wyoming", sizeIndex: 0.5 },
  { code: "DC", name: "Washington, D.C.", sizeIndex: -0.6 },
];

const BASE_DISTRIBUTION: Record<Size, number> = {
  XS: 0.020,
  S:  0.090,
  M:  0.200,
  L:  0.265,
  XL: 0.220,
  "2XL": 0.130,
  "3XL": 0.050,
  "4XL": 0.015,
  "5XL": 0.010,
};

const AUDIENCE_OFFSETS: Record<AudienceType, number[]> = {
  average:        [ 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000],
  younger:        [ 0.025, 0.035, 0.020, 0.010,-0.025,-0.040,-0.020,-0.003,-0.002],
  hs_students:    [ 0.040, 0.060, 0.030, 0.005,-0.040,-0.060,-0.025,-0.007,-0.003],
  women_focused:  [ 0.030, 0.040, 0.020, 0.005,-0.020,-0.040,-0.025,-0.007,-0.003],
  men_focused:    [-0.010,-0.015,-0.010, 0.015, 0.020, 0.025, 0.015, 0.005,-0.005],
  athletic:       [-0.005, 0.010, 0.030, 0.030, 0.010,-0.030,-0.030,-0.010,-0.005],
  plus_focused:   [-0.015,-0.050,-0.060,-0.030, 0.030, 0.050, 0.040, 0.020, 0.015],
  mixed_corporate:[-0.005,-0.010, 0.000, 0.010, 0.010, 0.010, 0.005,-0.005,-0.005],
};

function shiftDistribution(dist: number[], sizeIndex: number): number[] {
  const shifted = [...dist];
  const strength = sizeIndex * 0.012;

  for (let i = 0; i < shifted.length - 1; i++) {
    const transfer = shifted[i] * strength;
    shifted[i] -= transfer;
    shifted[i + 1] += transfer;
  }

  if (strength < 0) {
    for (let i = shifted.length - 1; i > 0; i--) {
      const transfer = shifted[i] * Math.abs(strength);
      shifted[i] -= transfer;
      shifted[i - 1] += transfer;
    }
  }

  return shifted.map((v) => Math.max(0, v));
}

function normalize(dist: number[]): number[] {
  const total = dist.reduce((a, b) => a + b, 0);
  return dist.map((v) => v / total);
}

export interface SizeBreakdown {
  size: Size;
  percentage: number;
  quantity: number;
  overridden: boolean;
}

export interface CalculationResult {
  breakdown: SizeBreakdown[];
  total: number;
  stateName?: string;
  audienceLabel: string;
  overridesExceedTotal: boolean;
  lockedTotal: number;
}

export function calculateSizes(
  quantity: number,
  audience: AudienceType,
  stateCode?: string,
  excludedSizes: Size[] = [],
  overrides: Partial<Record<Size, number>> = {}
): CalculationResult {
  let dist = SIZES.map((s) => BASE_DISTRIBUTION[s]);

  const audienceOffset = AUDIENCE_OFFSETS[audience];
  dist = dist.map((v, i) => v + (audienceOffset[i] || 0));
  dist = dist.map((v) => Math.max(0, v));
  dist = normalize(dist);

  let stateData: StateData | undefined;
  if (stateCode && stateCode !== "national") {
    stateData = STATES.find((s) => s.code === stateCode);
    if (stateData && stateData.sizeIndex !== 0) {
      dist = shiftDistribution(dist, stateData.sizeIndex);
      dist = normalize(dist);
    }
  }

  // Determine which sizes are overridden (locked) and active (not excluded)
  const activeOverrides: Partial<Record<Size, number>> = {};
  let lockedTotal = 0;
  for (const size of SIZES) {
    if (!excludedSizes.includes(size) && overrides[size] !== undefined) {
      const v = Math.max(0, Math.round(overrides[size]!));
      activeOverrides[size] = v;
      lockedTotal += v;
    }
  }

  const overridesExceedTotal = lockedTotal > quantity;

  // Zero out excluded and overridden sizes, renormalize free sizes
  dist = dist.map((v, i) => {
    const size = SIZES[i];
    if (excludedSizes.includes(size) || activeOverrides[size] !== undefined) return 0;
    return v;
  });

  const freeActive = dist.filter((v) => v > 0).length;
  if (freeActive > 0) {
    dist = normalize(dist);
  }

  // Remaining quantity goes to free (non-overridden, non-excluded) sizes
  const remaining = Math.max(0, quantity - lockedTotal);
  const rawQuantities = dist.map((p) => p * remaining);
  const floored = rawQuantities.map((q) => Math.floor(q));
  let rem = remaining - floored.reduce((a, b) => a + b, 0);

  const fractionals = rawQuantities.map((q, i) => ({
    index: i,
    frac: q - floored[i],
  }));
  fractionals.sort((a, b) => b.frac - a.frac);
  for (let i = 0; i < rem; i++) {
    floored[fractionals[i].index]++;
  }

  const audienceOption = AUDIENCE_OPTIONS.find((a) => a.value === audience);

  const breakdown: SizeBreakdown[] = SIZES.map((size, i) => {
    const isExcluded = excludedSizes.includes(size);
    const isOverridden = activeOverrides[size] !== undefined;
    const qty = isExcluded ? 0 : isOverridden ? activeOverrides[size]! : floored[i];
    return {
      size,
      percentage: isExcluded ? 0 : (qty / quantity) * 100,
      quantity: qty,
      overridden: isOverridden,
    };
  });

  return {
    breakdown,
    total: quantity,
    stateName: stateData?.name,
    audienceLabel: audienceOption?.label ?? audience,
    overridesExceedTotal,
    lockedTotal,
  };
}
