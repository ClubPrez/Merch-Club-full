import { useState, useMemo, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Shirt,
  Copy,
  Download,
  MapPin,
  Users,
  Hash,
  Info,
  CheckCircle2,
  SlidersHorizontal,
  X,
  Lock,
  LockOpen,
  AlertTriangle,
} from "lucide-react";
import {
  AUDIENCE_OPTIONS,
  STATES,
  calculateSizes,
  type AudienceType,
  type CalculationResult,
  type Size,
  SIZES,
} from "@/lib/sizeData";
import { useToast } from "@/hooks/use-toast";

const SIZE_COLORS: Record<string, string> = {
  XS:    "bg-violet-400 dark:bg-violet-500",
  S:     "bg-blue-400 dark:bg-blue-500",
  M:     "bg-sky-400 dark:bg-sky-500",
  L:     "bg-emerald-500 dark:bg-emerald-500",
  XL:    "bg-amber-400 dark:bg-amber-500",
  "2XL": "bg-orange-400 dark:bg-orange-500",
  "3XL": "bg-rose-400 dark:bg-rose-500",
  "4XL": "bg-pink-400 dark:bg-pink-500",
  "5XL": "bg-fuchsia-400 dark:bg-fuchsia-500",
};

const SIZE_DOT_COLORS: Record<string, string> = {
  XS:    "bg-violet-400",
  S:     "bg-blue-400",
  M:     "bg-sky-400",
  L:     "bg-emerald-500",
  XL:    "bg-amber-400",
  "2XL": "bg-orange-400",
  "3XL": "bg-rose-400",
  "4XL": "bg-pink-400",
  "5XL": "bg-fuchsia-400",
};

function SizeRow({
  label,
  percentage,
  quantity,
  max,
  excluded,
  overridden,
  totalQty,
  onLock,
  onUnlock,
}: {
  label: string;
  percentage: number;
  quantity: number;
  max: number;
  excluded: boolean;
  overridden: boolean;
  totalQty: number;
  onLock: (qty: number) => void;
  onUnlock: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const colorClass = SIZE_COLORS[label] ?? "bg-primary";
  const barWidth = max > 0 && !excluded ? (percentage / max) * 100 : 0;

  useEffect(() => {
    if (editing && inputRef.current) inputRef.current.focus();
  }, [editing]);

  function startEdit() {
    if (excluded) return;
    setDraft(quantity.toString());
    setEditing(true);
  }

  function commitEdit() {
    const parsed = parseInt(draft, 10);
    if (!isNaN(parsed) && parsed >= 0 && parsed <= totalQty) {
      onLock(parsed);
    }
    setEditing(false);
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === "Enter") commitEdit();
    if (e.key === "Escape") setEditing(false);
  }

  function handleLockIconClick() {
    if (overridden) {
      onUnlock();
    } else {
      // Lock at current calculated value
      onLock(quantity);
    }
  }

  return (
    <div
      className={`flex items-center gap-3 transition-opacity duration-200 ${excluded ? "opacity-35" : ""}`}
      data-testid={`size-row-${label}`}
    >
      {/* Size label */}
      <div className="w-10 flex-shrink-0 text-right">
        {excluded ? (
          <span className="text-xs text-muted-foreground line-through">{label}</span>
        ) : (
          <span className="text-sm font-semibold text-foreground">{label}</span>
        )}
      </div>

      {/* Bar */}
      <div className="flex-1 relative h-8 bg-muted rounded-md overflow-hidden">
        {excluded ? (
          <div className="absolute inset-0 flex items-center px-3">
            <span className="text-xs text-muted-foreground italic">excluded</span>
          </div>
        ) : (
          <>
            <div
              className={`absolute left-0 top-0 h-full transition-all duration-500 rounded-md ${colorClass} ${overridden ? "opacity-70" : ""}`}
              style={{ width: `${barWidth}%` }}
            />
            {overridden && (
              <div className="absolute left-0 top-0 h-full rounded-md border-2 border-blue-400 dark:border-blue-500 pointer-events-none" style={{ width: `${barWidth}%` }} />
            )}
            <div className="absolute inset-0 flex items-center justify-between px-3">
              <span
                className="text-xs font-medium text-white drop-shadow-sm"
                style={{ visibility: barWidth > 12 ? "visible" : "hidden" }}
              >
                {percentage.toFixed(1)}%
              </span>
            </div>
          </>
        )}
      </div>

      {/* Quantity — editable */}
      <div className="w-24 flex-shrink-0">
        {excluded ? (
          <span className="text-xs text-muted-foreground pl-1">—</span>
        ) : editing ? (
          <Input
            ref={inputRef}
            className="h-8 text-sm font-bold px-2 text-center"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commitEdit}
            onKeyDown={handleKey}
            type="number"
            min={0}
            max={totalQty}
            data-testid={`input-override-${label}`}
          />
        ) : (
          <button
            className={`w-full h-8 flex items-center justify-center gap-1 rounded-md text-sm font-bold transition-colors cursor-pointer
              ${overridden
                ? "bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-700"
                : "text-foreground"
              }`}
            onClick={startEdit}
            title="Click to set an exact quantity"
            data-testid={`quantity-${label}`}
          >
            <span>{quantity}</span>
            {!overridden && (
              <span className="text-xs text-muted-foreground font-normal hidden group-hover:inline">u</span>
            )}
          </button>
        )}
      </div>

      {/* Percentage */}
      <div className="w-12 flex-shrink-0 text-right">
        {!excluded && (
          <span className="text-xs text-muted-foreground">{percentage.toFixed(1)}%</span>
        )}
      </div>

      {/* Lock / Unlock button */}
      <div className="w-8 flex-shrink-0 flex items-center justify-center">
        {!excluded && (
          <button
            onClick={handleLockIconClick}
            title={overridden ? `Unlock ${label} (returns to auto-calculated)` : `Lock ${label} at ${quantity}`}
            data-testid={`lock-${label}`}
            className={`w-7 h-7 flex items-center justify-center rounded-md transition-colors cursor-pointer
              ${overridden
                ? "text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/40"
                : "text-muted-foreground/40"
              }`}
          >
            {overridden ? (
              <Lock className="w-3.5 h-3.5" />
            ) : (
              <LockOpen className="w-3.5 h-3.5" />
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function SizeToggleGrid({
  excludedSizes,
  onToggle,
  onReset,
}: {
  excludedSizes: Size[];
  onToggle: (size: Size) => void;
  onReset: () => void;
}) {
  const activeSizes = SIZES.filter((s) => !excludedSizes.includes(s));
  const hasExclusions = excludedSizes.length > 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-primary" />
            Available Sizes
          </CardTitle>
          {hasExclusions && (
            <button
              onClick={onReset}
              data-testid="button-reset-sizes"
              className="text-xs text-muted-foreground flex items-center gap-1 cursor-pointer"
            >
              <X className="w-3 h-3" />
              Reset
            </button>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">
          Click a size to exclude it entirely from the calculation.
        </p>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {SIZES.map((size) => {
            const isExcluded = excludedSizes.includes(size);
            const isLast = !isExcluded && activeSizes.length === 1;
            return (
              <button
                key={size}
                data-testid={`size-toggle-${size}`}
                onClick={() => !isLast && onToggle(size)}
                disabled={isLast && !isExcluded}
                title={
                  isLast && !isExcluded
                    ? "At least one size must remain active"
                    : isExcluded
                    ? `Include ${size}`
                    : `Exclude ${size}`
                }
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md border text-sm font-medium transition-all duration-150 cursor-pointer select-none
                  ${isExcluded
                    ? "bg-muted/40 border-border text-muted-foreground line-through opacity-50"
                    : isLast
                    ? "bg-card border-card-border text-foreground cursor-not-allowed"
                    : "bg-card border-card-border text-foreground"
                  }`}
              >
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${SIZE_DOT_COLORS[size]} ${isExcluded ? "opacity-30" : ""}`} />
                {size}
              </button>
            );
          })}
        </div>
        {hasExclusions && (
          <div className="mt-3 flex items-start gap-2 bg-accent rounded-md p-3">
            <Info className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground">
              {excludedSizes.join(", ")} {excludedSizes.length === 1 ? "is" : "are"} excluded — remaining sizes redistribute to fill your total.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ResultsPanel({
  result,
  excludedSizes,
  overrides,
  totalQty,
  onLock,
  onUnlock,
  onClearAllOverrides,
}: {
  result: CalculationResult;
  excludedSizes: Size[];
  overrides: Partial<Record<Size, number>>;
  totalQty: number;
  onLock: (size: Size, qty: number) => void;
  onUnlock: (size: Size) => void;
  onClearAllOverrides: () => void;
}) {
  const { toast } = useToast();

  const activeSizes = result.breakdown.filter((b) => !excludedSizes.includes(b.size));
  const lockedCount = Object.keys(overrides).filter((s) => !excludedSizes.includes(s as Size)).length;
  const maxPct = Math.max(...activeSizes.map((b) => b.percentage), 0);

  function copyToClipboard() {
    const lines = result.breakdown
      .filter((b) => !excludedSizes.includes(b.size))
      .map((b) => `${b.size}: ${b.quantity}${b.overridden ? " [locked]" : ""} (${b.percentage.toFixed(1)}%)`)
      .join("\n");
    const header = `Apparel Size Breakdown\nTotal: ${result.total} units\nAudience: ${result.audienceLabel}${result.stateName ? `\nLocation: ${result.stateName}` : ""}${lockedCount > 0 ? `\nLocked sizes: ${lockedCount}` : ""}\n\n`;
    navigator.clipboard.writeText(header + lines).then(() => {
      toast({ title: "Copied to clipboard", description: "Size breakdown copied successfully." });
    });
  }

  function downloadCSV() {
    const rows = [
      ["Size", "Quantity", "Percentage", "Status"],
      ...result.breakdown.map((b) => [
        b.size,
        excludedSizes.includes(b.size) ? "0" : b.quantity.toString(),
        excludedSizes.includes(b.size) ? "excluded" : b.percentage.toFixed(2) + "%",
        excludedSizes.includes(b.size) ? "excluded" : b.overridden ? "locked" : "calculated",
      ]),
      ["TOTAL", result.total.toString(), "100%", ""],
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "apparel-size-breakdown.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  const largerSizesTotal = activeSizes.filter((b) => ["2XL", "3XL", "4XL", "5XL"].includes(b.size)).reduce((s, b) => s + b.quantity, 0);
  const largerSizesPct = activeSizes.filter((b) => ["2XL", "3XL", "4XL", "5XL"].includes(b.size)).reduce((s, b) => s + b.percentage, 0);
  const topSize = activeSizes.length > 0 ? activeSizes.reduce((a, b) => (b.quantity > a.quantity ? b : a)) : null;

  return (
    <div className="flex flex-col gap-4">
      {/* Header row */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Size Breakdown</h2>
          <p className="text-sm text-muted-foreground flex flex-wrap gap-1 items-center">
            <span>{result.total.toLocaleString()} units</span>
            {result.stateName && <span>· {result.stateName}</span>}
            <span>· {result.audienceLabel}</span>
            {lockedCount > 0 && (
              <span className="text-blue-600 dark:text-blue-400">· {lockedCount} locked</span>
            )}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {lockedCount > 0 && (
            <Button variant="ghost" size="sm" onClick={onClearAllOverrides} data-testid="button-clear-locks">
              <LockOpen className="w-3.5 h-3.5 mr-1.5" />
              Clear locks
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={copyToClipboard} data-testid="button-copy">
            <Copy className="w-4 h-4 mr-1.5" />
            Copy
          </Button>
          <Button variant="outline" size="sm" onClick={downloadCSV} data-testid="button-download-csv">
            <Download className="w-4 h-4 mr-1.5" />
            CSV
          </Button>
        </div>
      </div>

      {/* Override exceeds total warning */}
      {result.overridesExceedTotal && (
        <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-md p-3">
          <AlertTriangle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
          <p className="text-sm text-destructive">
            Locked quantities ({result.lockedTotal}) exceed your total order ({result.total}). Reduce locked amounts or increase your total quantity.
          </p>
        </div>
      )}

      {/* Column header labels */}
      <div className="flex items-center gap-3 px-0">
        <div className="w-10 flex-shrink-0" />
        <div className="flex-1 text-xs text-muted-foreground">Distribution</div>
        <div className="w-24 flex-shrink-0 text-xs text-muted-foreground text-center">
          Qty <span className="opacity-60">(click to set)</span>
        </div>
        <div className="w-12 flex-shrink-0 text-right text-xs text-muted-foreground">%</div>
        <div className="w-8 flex-shrink-0 text-center text-xs text-muted-foreground">
          <Lock className="w-3 h-3 inline" />
        </div>
      </div>

      {/* Size rows */}
      <Card>
        <CardContent className="pt-4 pb-4">
          <div className="flex flex-col gap-2.5">
            {result.breakdown.map((b) => (
              <SizeRow
                key={b.size}
                label={b.size}
                percentage={b.percentage}
                quantity={b.quantity}
                max={maxPct}
                excluded={excludedSizes.includes(b.size)}
                overridden={b.overridden}
                totalQty={totalQty}
                onLock={(qty) => onLock(b.size, qty)}
                onUnlock={() => onUnlock(b.size)}
              />
            ))}
          </div>

          {lockedCount > 0 && !result.overridesExceedTotal && (
            <div className="mt-4 pt-3 border-t border-border flex items-start gap-2">
              <Lock className="w-3.5 h-3.5 text-blue-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">
                <span className="text-blue-600 dark:text-blue-400 font-medium">{result.lockedTotal} units locked</span>
                {" · "}
                <span>{result.total - result.lockedTotal} units distributed proportionally across {activeSizes.filter((b) => !b.overridden).length} unlocked sizes</span>
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Hint for lock interaction */}
      {lockedCount === 0 && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground px-1">
          <LockOpen className="w-3.5 h-3.5 flex-shrink-0" />
          <span>Click any quantity to override it, or click <Lock className="w-3 h-3 inline mx-0.5" /> to lock a size at its current value</span>
        </div>
      )}

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          {
            label: "Most Popular",
            value: topSize ? topSize.size : "—",
            sub: topSize ? `${topSize.quantity} units` : "no active sizes",
            color: "text-emerald-600 dark:text-emerald-400",
          },
          {
            label: "S + M + L",
            value: activeSizes.filter((b) => ["S", "M", "L"].includes(b.size)).reduce((s, b) => s + b.quantity, 0).toString(),
            sub: activeSizes.filter((b) => ["S", "M", "L"].includes(b.size)).reduce((s, b) => s + b.percentage, 0).toFixed(0) + "% of order",
            color: "text-blue-600 dark:text-blue-400",
          },
          {
            label: "2XL and up",
            value: largerSizesTotal.toString(),
            sub: largerSizesPct.toFixed(0) + "% of order",
            color: "text-orange-600 dark:text-orange-400",
          },
          {
            label: "Unique Sizes",
            value: activeSizes.filter((b) => b.quantity > 0).length.toString(),
            sub: `active${lockedCount > 0 ? ` · ${lockedCount} locked` : ""}`,
            color: "text-violet-600 dark:text-violet-400",
          },
        ].map((stat) => (
          <Card key={stat.label} data-testid={`stat-${stat.label.replace(/\s/g, "-").toLowerCase()}`}>
            <CardContent className="pt-4 pb-4">
              <p className="text-xs text-muted-foreground mb-1">{stat.label}</p>
              <p className={`text-xl font-bold ${stat.color}`}>{stat.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick-view chips */}
      <Card>
        <CardContent className="pt-4 pb-4">
          <div className="flex flex-wrap gap-2">
            {result.breakdown
              .filter((b) => !excludedSizes.includes(b.size))
              .map((b) => (
                <div
                  key={b.size}
                  className={`flex items-center gap-2 rounded-md px-3 py-2 flex-shrink-0 ${
                    b.overridden
                      ? "bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-700"
                      : "bg-muted"
                  }`}
                  data-testid={`chip-${b.size}`}
                >
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${SIZE_DOT_COLORS[b.size]}`} />
                  <span className="text-sm font-semibold text-foreground">{b.size}</span>
                  <span className="text-sm text-muted-foreground">×{b.quantity}</span>
                  {b.overridden && <Lock className="w-3 h-3 text-blue-500 flex-shrink-0" />}
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Calculator() {
  const [quantity, setQuantity] = useState<string>("100");
  const [audience, setAudience] = useState<AudienceType>("average");
  const [stateCode, setStateCode] = useState<string>("national");
  const [excludedSizes, setExcludedSizes] = useState<Size[]>([]);
  const [overrides, setOverrides] = useState<Partial<Record<Size, number>>>({});

  const qty = parseInt(quantity, 10);
  const isValid = !isNaN(qty) && qty >= 1 && qty <= 100000;

  function toggleSize(size: Size) {
    setExcludedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
    // Remove override if size gets excluded
    setOverrides((prev) => {
      const next = { ...prev };
      delete next[size];
      return next;
    });
  }

  function resetExclusions() {
    setExcludedSizes([]);
  }

  function lockSize(size: Size, qty: number) {
    setOverrides((prev) => ({ ...prev, [size]: qty }));
  }

  function unlockSize(size: Size) {
    setOverrides((prev) => {
      const next = { ...prev };
      delete next[size];
      return next;
    });
  }

  function clearAllOverrides() {
    setOverrides({});
  }

  const displayResult = useMemo(() => {
    if (!isValid) return null;
    return calculateSizes(
      qty,
      audience,
      stateCode === "national" ? undefined : stateCode,
      excludedSizes,
      overrides
    );
  }, [qty, audience, stateCode, excludedSizes, overrides, isValid]);

  const lockedCount = Object.keys(overrides).filter((s) => !excludedSizes.includes(s as Size)).length;
  const selectedAudience = AUDIENCE_OPTIONS.find((a) => a.value === audience);
  const selectedState = STATES.find((s) => s.code === stateCode);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center flex-shrink-0">
              <Shirt className="w-4 h-4 text-primary-foreground" />
            </div>
            <div>
              <span className="font-bold text-foreground text-sm sm:text-base">Apparel Size Calculator</span>
              <span className="hidden sm:inline text-muted-foreground text-sm ml-2">· Bulk Branded Tops</span>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            {excludedSizes.length > 0 && (
              <Badge variant="secondary" className="flex-shrink-0 text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-900/40">
                {SIZES.length - excludedSizes.length} of {SIZES.length} sizes
              </Badge>
            )}
            {lockedCount > 0 && (
              <Badge variant="secondary" className="flex-shrink-0 text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-900/40">
                <Lock className="w-3 h-3 mr-1" />
                {lockedCount} locked
              </Badge>
            )}
            <Badge variant="secondary" className="flex-shrink-0">XS – 5XL</Badge>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Bulk Size Estimator</h1>
          <p className="text-muted-foreground max-w-2xl">
            Enter your order quantity and configure your audience. Override any size with a specific count,
            or lock it to prevent it from changing — the rest will redistribute automatically.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[340px,1fr] gap-6">
          {/* Left panel — settings */}
          <div className="flex flex-col gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Hash className="w-4 h-4 text-primary" />
                  Order Quantity
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                <div>
                  <Label htmlFor="input-quantity" className="text-sm mb-1.5 block">Total units to order</Label>
                  <Input
                    id="input-quantity"
                    data-testid="input-quantity"
                    type="number"
                    min={1}
                    max={100000}
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder="e.g. 100"
                    className="text-lg font-semibold"
                  />
                  {quantity && !isValid && (
                    <p className="text-xs text-destructive mt-1.5">Enter a number between 1 and 100,000</p>
                  )}
                </div>
                <div className="flex gap-2 flex-wrap">
                  {[24, 48, 100, 250, 500, 1000].map((q) => (
                    <button
                      key={q}
                      data-testid={`preset-${q}`}
                      onClick={() => setQuantity(q.toString())}
                      className={`text-xs px-2.5 py-1 rounded-md border transition-colors cursor-pointer ${
                        parseInt(quantity) === q
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-muted text-muted-foreground border-transparent"
                      }`}
                    >
                      {q.toLocaleString()}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  Audience Type
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                <div>
                  <Label htmlFor="select-audience" className="text-sm mb-1.5 block">Who is this order for?</Label>
                  <Select value={audience} onValueChange={(v) => setAudience(v as AudienceType)}>
                    <SelectTrigger id="select-audience" data-testid="select-audience">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {AUDIENCE_OPTIONS.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value} data-testid={`audience-option-${opt.value}`}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedAudience && (
                  <div className="flex items-start gap-2 bg-accent rounded-md p-3">
                    <Info className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">{selectedAudience.description}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  Location
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                <div>
                  <Label htmlFor="select-state" className="text-sm mb-1.5 block">State / Region</Label>
                  <Select value={stateCode} onValueChange={setStateCode}>
                    <SelectTrigger id="select-state" data-testid="select-state">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-64">
                      <SelectItem value="national" data-testid="state-option-national">
                        National Average (No Adjustment)
                      </SelectItem>
                      <Separator className="my-1" />
                      {STATES.sort((a, b) => a.name.localeCompare(b.name)).map((s) => (
                        <SelectItem key={s.code} value={s.code} data-testid={`state-option-${s.code}`}>
                          {s.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedState && (
                  <div className="flex items-start gap-2 bg-accent rounded-md p-3">
                    <Info className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">
                      {selectedState.name} has a{" "}
                      {selectedState.sizeIndex > 0.5 ? "larger-than-average" : selectedState.sizeIndex < -0.5 ? "smaller-than-average" : "near-average"}{" "}
                      body size profile based on CDC obesity and body measurement data.
                    </p>
                  </div>
                )}
                {stateCode === "national" && (
                  <div className="flex items-start gap-2 bg-accent rounded-md p-3">
                    <Info className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">
                      Using national average. Select a state to adjust for regional body size data.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <SizeToggleGrid
              excludedSizes={excludedSizes}
              onToggle={toggleSize}
              onReset={resetExclusions}
            />
          </div>

          {/* Right panel — results */}
          <div className="flex flex-col gap-4">
            {displayResult && isValid ? (
              <ResultsPanel
                result={displayResult}
                excludedSizes={excludedSizes}
                overrides={overrides}
                totalQty={qty}
                onLock={lockSize}
                onUnlock={unlockSize}
                onClearAllOverrides={clearAllOverrides}
              />
            ) : (
              <div className="flex flex-col items-center justify-center h-full min-h-64 text-center bg-card border border-card-border rounded-lg p-8">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                  <Shirt className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Enter a quantity to begin</h3>
                <p className="text-sm text-muted-foreground max-w-xs">
                  Fill in your order details on the left to see your size breakdown.
                </p>
              </div>
            )}

            {displayResult && isValid && (
              <Card className="border-card-border">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-medium text-foreground mb-1">How overrides & locks work</p>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Click any quantity to type an exact number — that size is immediately locked to your value and the remaining units redistribute among all unlocked sizes.
                        Click <Lock className="w-3 h-3 inline mx-0.5" /> on an unlocked size to freeze it at its current calculated value.
                        Locked sizes persist when you change audience, state, or total quantity.
                        Click <LockOpen className="w-3 h-3 inline mx-0.5" /> to release a lock.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
