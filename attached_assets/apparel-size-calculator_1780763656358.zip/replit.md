# Apparel Size Calculator

A bulk branded apparel size calculator that helps buyers determine optimal size distribution for orders of shirts, hoodies, sweatshirts, and similar tops (XS–5XL).

## Features

- **Quantity input** with quick-select presets (24, 48, 100, 250, 500, 1000)
- **Audience type presets** — General, Younger (18-30), Women-Focused, Men-Focused, Athletic, Plus/Larger, Corporate
- **State-based size adjustment** — uses CDC obesity/body size statistics per state to shift distributions
- **Live preview** — results update in real-time as inputs change
- **Visual breakdown** — color-coded bar chart per size with percentages and unit counts
- **Summary stats** — most popular size, core sizes total, 2XL+ count
- **Export** — copy to clipboard or download as CSV

## Architecture

- **Frontend-only** — pure React calculator, no database required
- `client/src/lib/sizeData.ts` — all size distribution logic, state data, audience offsets
- `client/src/pages/calculator.tsx` — main calculator UI
- `client/src/App.tsx` — routing

## Size Logic

- Base distribution: L is most popular (~26.5%), followed by XL (~22%) and M (~20%)
- Audience offsets shift the curve toward smaller or larger sizes
- State index (-2 to +2) cascades mass through adjacent sizes in the distribution
- Final quantities are rounded to integers with remainder distributed to highest-weight sizes

## Tech Stack

- React + TypeScript + Vite
- Tailwind CSS + shadcn/ui components
- wouter for routing
- No backend persistence needed (calculator only)
