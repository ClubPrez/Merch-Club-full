# SEO Strategy

## In scope
- Public homepage calculator at `/`
- Static HTML shell and crawler-facing assets
- Social sharing and AI crawler visibility for the public route

## Out of scope
- Authenticated dashboard routes (none found)
- Admin/internal tools (none found)

## Target audience
- Buyers ordering bulk branded apparel who need a fast size-mix estimate.

## Primary keywords
- apparel size calculator
- bulk apparel size calculator
- branded apparel size estimator
- shirt size breakdown calculator

## Dismissed categories
- (None yet)
